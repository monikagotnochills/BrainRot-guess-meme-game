// Game data from the provided JSON
const gameData = {
  gameRounds: [
    {
      id: 1,
      clue: "This pasta-faced warrior speaks only in ancient spaghetti wisdom and guards the sacred marinara scrolls",
      options: ["Il Spaghettone", "Mama Meatballini", "Giuseppe Gorgonzola"],
      correct: 0,
      character: "ðð"
    },
    {
      id: 2,
      clue: "Guardian of cursed carbonara, destroyer of taste buds, master of the forbidden cheese arts",
      options: ["Signore Parmigiano", "Don Cannelloni", "Fratello Formaggio"],
      correct: 2,
      character: "ð§ð"
    },
    {
      id: 3,
      clue: "This gelato-powered entity freezes time itself and speaks in frozen dairy prophecies",
      options: ["Gelato Supremo", "Ice Cream Imperator", "Freddo Magnifico"],
      correct: 0,
      character: "ð¦âï¸"
    },
    {
      id: 4,
      clue: "Pizza-dimensional being that exists between crust and sauce, defying all laws of Italian physics",
      options: ["Margherita Mystic", "Pepperoni Phantom", "Il Pizzaiolo Cosmico"],
      correct: 2,
      character: "ðð"
    },
    {
      id: 5,
      clue: "The final boss of Italian chaos - a ravioli-shaped entity containing infinite universes of confusion",
      options: ["Ravioli Rex", "Pasta Overlord", "The Chosen Gnocchi"],
      correct: 0,
      character: "ð¥ð"
    }
  ],
  winningMessages: [
    "ALPHA HIT! ð¥",
    "YOU COOKED! ð¨âð³",
    "PASTA LA VISTA! ð",
    "SPICE CONFIRMED! ð¶ï¸",
    "NEURON ACTIVATED! â¡"
  ],
  scoreResponses: {
    "0": {
      bigLine: "BROâ¦ did you play with your eyes closed?? ð",
      phrases: [
        "Neurons? You mean raisins.",
        "You failed the vibe check AND the meme check.",
        "Go touch grass... but like, ironically.",
        "This ain't a trial. This was a crime scene."
      ]
    },
    "1": {
      bigLine: "Barely alive. Like a spaghetti noodle in a thunderstorm.",
      phrases: [
        "Your brain is bufferingâ¦ still.",
        "One neuron said 'I got this', the rest went on strike.",
        "At least you tried. Kinda. Not really."
      ]
    },
    "2": {
      bigLine: "Okay... you're walking, but the shoes are upside down.",
      phrases: [
        "Two correct? That's two more than expected. Bravo?",
        "Mild sauce brainrot. Needs more chaos.",
        "You blinked and accidentally got one right."
      ]
    },
    "3": {
      bigLine: "Mid-level brainrot. You're cursed, but inconsistently.",
      phrases: [
        "You exist in the uncanny valley of memes.",
        "You've unlocked: 'I think I get it, but also I don't.'",
        "Half-brain half-brainrot. A balanced breakfast."
      ]
    },
    "4": {
      bigLine: "Okay okay, the neurons are simmering.",
      phrases: [
        "Almost there, just one synapse short of greatness.",
        "You're entering dangerous meme territory. Proceed with delusion.",
        "Your brainrot is spicy, but not extra crispy."
      ]
    },
    "5": {
      bigLine: "Certified Midbrain Meme Monk ð§",
      phrases: [
        "You surf chaos like it's WiFi.",
        "5? That's suspiciously competent.",
        "You've officially joined the ranks of semi-enlightened degenerates."
      ]
    }
  },
  floatingEmojis: ["ð", "ð§", "ð", "ð¦", "ð¥", "ð", "ð¤", "ð¥", "ð", "â¡", "ð", "ð"]
};

// Game state
let gameState = {
  currentRound: 0,
  score: 0,
  username: 'Guest',
  isLoggedIn: false,
  rounds: gameData.gameRounds,
  answerInProgress: false
};

// DOM elements
let elements = {};
let screens = {};

// Initialize the application
function init() {
  console.log('Initializing Italian Brainrot Trials...');
  
  // Get DOM elements
  screens = {
    landing: document.getElementById('landingPage'),
    login: document.getElementById('loginScreen'),
    game: document.getElementById('gameScreen'),
    results: document.getElementById('resultsScreen')
  };

  elements = {
    themeToggle: document.getElementById('themeToggle'),
    enterGame: document.getElementById('enterGame'),
    loginGoogle: document.getElementById('loginGoogle'),
    playGuest: document.getElementById('playGuest'),
    usernameInput: document.getElementById('usernameInput'),
    passwordInput: document.getElementById('passwordInput'),
    confirmLogin: document.getElementById('confirmLogin'),
    backToLanding: document.getElementById('backToLanding'),
    currentRound: document.getElementById('currentRound'),
    currentUser: document.getElementById('currentUser'),
    hiddenCharacter: document.getElementById('hiddenCharacter'),
    gameClue: document.getElementById('gameClue'),
    option1: document.getElementById('option1'),
    option2: document.getElementById('option2'),
    option3: document.getElementById('option3'),
    answerFeedback: document.getElementById('answerFeedback'),
    feedbackText: document.getElementById('feedbackText'),
    characterReveal: document.getElementById('characterReveal'),
    nextRound: document.getElementById('nextRound'),
    finalScore: document.getElementById('finalScore'),
    bigLine: document.getElementById('bigLine'),
    randomPhrase: document.getElementById('randomPhrase'),
    playAgain: document.getElementById('playAgain'),
    shareTwitter: document.getElementById('shareTwitter')
  };

  setupEventListeners();
  initializeFloatingAnimation();
  
  // Set initial theme
  const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  if (prefersDark) {
    document.documentElement.setAttribute('data-color-scheme', 'dark');
    elements.themeToggle.textContent = 'âï¸';
  } else {
    document.documentElement.setAttribute('data-color-scheme', 'light');
    elements.themeToggle.textContent = 'ð';
  }
  
  console.log('Italian Brainrot Trials initialized successfully!');
}

// Event listeners
function setupEventListeners() {
  console.log('Setting up event listeners...');
  
  // Theme toggle
  if (elements.themeToggle) {
    elements.themeToggle.addEventListener('click', toggleTheme);
  }
  
  // Landing page buttons
  if (elements.enterGame) {
    elements.enterGame.addEventListener('click', (e) => {
      e.preventDefault();
      startGameAsGuest();
    });
  }
  
  if (elements.loginGoogle) {
    elements.loginGoogle.addEventListener('click', (e) => {
      e.preventDefault();
      showScreen('login');
    });
  }
  
  if (elements.playGuest) {
    elements.playGuest.addEventListener('click', (e) => {
      e.preventDefault();
      startGameAsGuest();
    });
  }
  
  // Login screen
  if (elements.confirmLogin) {
    elements.confirmLogin.addEventListener('click', confirmLogin);
  }
  
  if (elements.backToLanding) {
    elements.backToLanding.addEventListener('click', () => showScreen('landing'));
  }
  
  if (elements.usernameInput) {
    elements.usernameInput.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') confirmLogin();
    });
  }
  
  if (elements.passwordInput) {
    elements.passwordInput.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') confirmLogin();
    });
  }
  
  // Game options
  if (elements.option1) {
    elements.option1.addEventListener('click', () => selectAnswer(0));
  }
  if (elements.option2) {
    elements.option2.addEventListener('click', () => selectAnswer(1));
  }
  if (elements.option3) {
    elements.option3.addEventListener('click', () => selectAnswer(2));
  }
  if (elements.nextRound) {
    elements.nextRound.addEventListener('click', nextRound);
  }
  
  // Results screen
  if (elements.playAgain) {
    elements.playAgain.addEventListener('click', resetGame);
  }
  if (elements.shareTwitter) {
    elements.shareTwitter.addEventListener('click', shareOnTwitter);
  }
  
  console.log('Event listeners setup complete');
}

// Screen management
function showScreen(screenName) {
  console.log('Showing screen:', screenName);
  
  // Hide all screens
  Object.values(screens).forEach(screen => {
    if (screen) screen.classList.remove('active');
  });
  
  // Show target screen
  if (screens[screenName]) {
    screens[screenName].classList.add('active');
  }
  
  if (screenName === 'game') {
    startGame();
  }
}

// Theme toggle
function toggleTheme() {
  console.log('Toggle theme clicked');
  const currentTheme = document.documentElement.getAttribute('data-color-scheme');
  const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
  
  document.documentElement.setAttribute('data-color-scheme', newTheme);
  
  if (elements.themeToggle) {
    elements.themeToggle.textContent = newTheme === 'dark' ? 'âï¸' : 'ð';
  }
  
  // Add glitch effect
  if (elements.themeToggle) {
    elements.themeToggle.classList.add('glitch-effect');
    setTimeout(() => elements.themeToggle.classList.remove('glitch-effect'), 900);
  }
  
  showDramaticMessage(newTheme === 'dark' ? "DARKNESS EMBRACED! ð" : "LIGHT MODE ACTIVATED! âï¸", 1500);
}

// Login confirmation
function confirmLogin() {
  const username = elements.usernameInput ? elements.usernameInput.value.trim() : '';
  const password = elements.passwordInput ? elements.passwordInput.value : '';
  
  if (username) {
    gameState.username = username;
    gameState.isLoggedIn = true;
    if (elements.currentUser) {
      elements.currentUser.textContent = gameState.username;
    }
    showScreen('game');
    showDramaticMessage("CHAOS ACCEPTED, " + username.toUpperCase() + "! ð", 2000);
  } else {
    showDramaticMessage("ENTER A NAME, YOU COWARD! ð¥", 2000);
    if (elements.usernameInput) {
      elements.usernameInput.focus();
    }
  }
}

// Start game as guest
function startGameAsGuest() {
  console.log('Starting game as guest');
  gameState.username = 'Chaotic Guest';
  gameState.isLoggedIn = false;
  if (elements.currentUser) {
    elements.currentUser.textContent = gameState.username;
  }
  showScreen('game');
  showDramaticMessage("WELCOME TO CHAOS, STRANGER! ð½", 2000);
}

// Game logic
function startGame() {
  console.log('Starting game');
  gameState.currentRound = 0;
  gameState.score = 0;
  gameState.answerInProgress = false;
  loadRound();
}

function loadRound() {
  const round = gameState.rounds[gameState.currentRound];
  console.log('Loading round:', gameState.currentRound + 1, round);
  
  gameState.answerInProgress = false;
  
  // Update UI
  if (elements.currentRound) elements.currentRound.textContent = gameState.currentRound + 1;
  if (elements.gameClue) elements.gameClue.textContent = round.clue;
  if (elements.option1) elements.option1.textContent = round.options[0];
  if (elements.option2) elements.option2.textContent = round.options[1];
  if (elements.option3) elements.option3.textContent = round.options[2];
  
  // Reset option buttons - clear all classes first
  [elements.option1, elements.option2, elements.option3].forEach(btn => {
    if (btn) {
      btn.classList.remove('correct', 'wrong');
      btn.disabled = false;
      btn.style.animation = '';
      btn.style.boxShadow = '';
      btn.style.border = '';
    }
  });
  
  // Update hidden character with mystery symbol and actual character
  if (elements.hiddenCharacter) {
    elements.hiddenCharacter.textContent = round.character;
    // Add blur overlay to hide the character initially
    const preview = elements.hiddenCharacter.parentElement;
    if (preview) {
      const blurOverlay = preview.querySelector('.blur-overlay');
      if (blurOverlay) {
        blurOverlay.style.display = 'block';
      }
    }
  }
  
  // Hide feedback
  if (elements.answerFeedback) {
    elements.answerFeedback.classList.add('hidden');
  }
}

function selectAnswer(selectedIndex) {
  // Prevent multiple clicks during answer processing
  if (gameState.answerInProgress) {
    return;
  }
  
  gameState.answerInProgress = true;
  
  const round = gameState.rounds[gameState.currentRound];
  const isCorrect = selectedIndex === round.correct;
  
  console.log('Answer selected:', selectedIndex, 'Correct:', round.correct, 'Is correct:', isCorrect);
  
  // Immediately disable all buttons and clear any previous styling
  const buttons = [elements.option1, elements.option2, elements.option3];
  buttons.forEach((btn, index) => {
    if (btn) {
      btn.disabled = true;
      btn.classList.remove('correct', 'wrong');
      btn.style.animation = '';
      btn.style.boxShadow = '';
      btn.style.border = '';
    }
  });
  
  // Apply visual feedback with proper delays
  setTimeout(() => {
    const selectedButton = buttons[selectedIndex];
    const correctButton = buttons[round.correct];
    
    if (isCorrect) {
      if (selectedButton) {
        selectedButton.classList.add('correct');
      }
      gameState.score++;
    } else {
      if (selectedButton) {
        selectedButton.classList.add('wrong');
      }
      // Only highlight correct button if it's different from selected
      if (correctButton && correctButton !== selectedButton) {
        setTimeout(() => {
          if (correctButton) {
            correctButton.classList.add('correct');
          }
        }, 200); // Small delay to avoid simultaneous highlighting
      }
      
      // Screen shake for wrong answer
      document.body.classList.add('screen-shake');
      setTimeout(() => document.body.classList.remove('screen-shake'), 500);
    }
    
    // Remove blur from character preview
    const preview = elements.hiddenCharacter.parentElement;
    if (preview) {
      const blurOverlay = preview.querySelector('.blur-overlay');
      if (blurOverlay) {
        blurOverlay.style.display = 'none';
      }
    }
    
    // Show feedback after visual effects
    setTimeout(() => showAnswerFeedback(isCorrect, round), 800);
    
  }, 100); // Small delay to ensure clean button state reset
}

function showAnswerFeedback(isCorrect, round) {
  if (!elements.answerFeedback) return;
  
  elements.answerFeedback.classList.remove('hidden');
  
  if (isCorrect) {
    const winningMessage = gameData.winningMessages[Math.floor(Math.random() * gameData.winningMessages.length)];
    if (elements.feedbackText) {
      elements.feedbackText.textContent = winningMessage;
      elements.feedbackText.className = 'feedback-text correct';
    }
  } else {
    if (elements.feedbackText) {
      elements.feedbackText.textContent = "YOU GOT LIQUIFIED ðð¥";
      elements.feedbackText.className = 'feedback-text wrong';
    }
  }
  
  if (elements.characterReveal) {
    elements.characterReveal.textContent = `Character Revealed: ${round.character}`;
  }
  
  // Update next round button text
  if (elements.nextRound) {
    if (gameState.currentRound >= 4) {
      elements.nextRound.textContent = "SEE RESULTS";
    } else {
      elements.nextRound.textContent = "NEXT ROUND";
    }
  }
}

function nextRound() {
  gameState.currentRound++;
  
  if (gameState.currentRound >= 5) {
    showResults();
  } else {
    loadRound();
  }
}

function showResults() {
  showScreen('results');
  
  const score = gameState.score;
  const scoreData = gameData.scoreResponses[score.toString()];
  
  if (elements.finalScore) elements.finalScore.textContent = score;
  if (elements.bigLine) elements.bigLine.textContent = scoreData.bigLine;
  
  // Random phrase from the score data
  const randomPhrase = scoreData.phrases[Math.floor(Math.random() * scoreData.phrases.length)];
  if (elements.randomPhrase) elements.randomPhrase.textContent = randomPhrase;
  
  // Add dramatic entrance animation
  setTimeout(() => {
    if (elements.finalScore && elements.finalScore.parentElement) {
      elements.finalScore.parentElement.classList.add('glitch-effect');
    }
  }, 500);
  
  // Show dramatic message based on score
  const messages = {
    0: "ABSOLUTE DISASTER! ð",
    1: "BARELY BREATHING! ðµ",
    2: "CONFUSION CONFIRMED! ð¤¯",
    3: "MILD CHAOS ACHIEVED! ð¥",
    4: "SPICY BRAIN DETECTED! ð¶ï¸",
    5: "MEME MASTER UNLOCKED! ð"
  };
  
  setTimeout(() => {
    showDramaticMessage(messages[score] || "CHAOS COMPLETE! ð", 2500);
  }, 1000);
}

function resetGame() {
  gameState.currentRound = 0;
  gameState.score = 0;
  gameState.answerInProgress = false;
  showScreen('landing');
  showDramaticMessage("READY FOR MORE CHAOS? ð", 1500);
}

function shareOnTwitter() {
  const score = gameState.score;
  const scoreData = gameData.scoreResponses[score.toString()];
  
  const tweetText = `Just finished playing BRAINROT TRIALS by [@StudiosBrainrot] ð§ 
User Experience:
90% confused
100% emotionally damaged  
200% entertained
ð Final Score: ${score}/5
Verdict: "${scoreData.bigLine}"`;
  
  const twitterUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(tweetText)}`;
  window.open(twitterUrl, '_blank');
  
  showDramaticMessage("SHARING THE CHAOS! ð¦", 1500);
}

// Floating animation system
function initializeFloatingAnimation() {
  const floatingElements = document.querySelectorAll('.floating-char');
  
  floatingElements.forEach((element, index) => {
    // Randomize initial positions
    element.style.top = Math.random() * 70 + 15 + '%';
    element.style.left = Math.random() * 70 + 15 + '%';
    
    // Add random movement
    function moveRandomly() {
      const newTop = Math.random() * 70 + 15 + '%';
      const newLeft = Math.random() * 70 + 15 + '%';
      const duration = 4 + Math.random() * 6;
      
      element.style.transition = `all ${duration}s ease-in-out`;
      element.style.top = newTop;
      element.style.left = newLeft;
      
      // Schedule next movement
      setTimeout(moveRandomly, (duration * 1000) + Math.random() * 3000);
    }
    
    // Start movement with initial delay
    setTimeout(moveRandomly, Math.random() * 5000);
  });
}

// Dramatic message system
function showDramaticMessage(message, duration) {
  const messageElement = document.createElement('div');
  messageElement.style.cssText = `
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background: rgba(0, 0, 0, 0.95);
    color: #D4B942;
    padding: 25px 40px;
    border: 3px solid #39FF14;
    border-radius: 15px;
    font-size: 1.2rem;
    font-weight: bold;
    z-index: 9999;
    text-align: center;
    animation: correctPulse 1s ease;
    font-family: 'Press Start 2P', monospace;
    box-shadow: 0 0 30px rgba(57, 255, 20, 0.5);
    max-width: 90vw;
    line-height: 1.4;
  `;
  messageElement.textContent = message;
  
  document.body.appendChild(messageElement);
  
  setTimeout(() => {
    if (messageElement.parentNode) {
      messageElement.style.opacity = '0';
      messageElement.style.transform = 'translate(-50%, -50%) scale(0.8)';
      setTimeout(() => {
        if (messageElement.parentNode) {
          messageElement.parentNode.removeChild(messageElement);
        }
      }, 300);
    }
  }, duration);
}

// Enhanced button interactions
function setupButtonInteractions() {
  const buttons = document.querySelectorAll('.btn');
  
  buttons.forEach(button => {
    button.addEventListener('mouseenter', () => {
      if (!button.disabled) {
        button.style.transform = 'translateY(-2px) scale(1.02)';
      }
    });
    
    button.addEventListener('mouseleave', () => {
      if (!button.disabled) {
        button.style.transform = 'translateY(0) scale(1)';
      }
    });
    
    button.addEventListener('mousedown', () => {
      if (!button.disabled) {
        button.style.transform = 'translateY(1px) scale(0.98)';
      }
    });
    
    button.addEventListener('mouseup', () => {
      if (!button.disabled) {
        button.style.transform = 'translateY(0) scale(1)';
      }
    });
  });
}

// Konami code easter egg
let konamiCode = [];
const konamiSequence = ['ArrowUp', 'ArrowUp', 'ArrowDown', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'ArrowLeft', 'ArrowRight', 'KeyB', 'KeyA'];

document.addEventListener('keydown', (e) => {
  konamiCode.push(e.code);
  
  if (konamiCode.length > konamiSequence.length) {
    konamiCode.shift();
  }
  
  if (JSON.stringify(konamiCode) === JSON.stringify(konamiSequence)) {
    showDramaticMessage("ð PASTA POWER ACTIVATED! ULTIMATE CHAOS UNLOCKED! ð", 4000);
    
    // Add special effects
    document.body.style.animation = 'glitch 0.5s ease-in-out 5';
    
    // Briefly show all correct answers with special glow
    const buttons = [elements.option1, elements.option2, elements.option3];
    const currentRound = gameState.rounds[gameState.currentRound];
    if (currentRound && buttons[currentRound.correct] && !gameState.answerInProgress) {
      buttons[currentRound.correct].style.boxShadow = '0 0 30px #39FF14';
      buttons[currentRound.correct].style.border = '3px solid #39FF14';
      setTimeout(() => {
        if (buttons[currentRound.correct]) {
          buttons[currentRound.correct].style.boxShadow = '';
          buttons[currentRound.correct].style.border = '2px solid #D4B942';
        }
      }, 8000);
    }
    
    konamiCode = [];
  }
});

// Random chaos events
function initializeChaosEvents() {
  // Random screen glitches
  setInterval(() => {
    if (Math.random() < 0.02) { // 2% chance every interval
      document.body.classList.add('glitch-effect');
      setTimeout(() => document.body.classList.remove('glitch-effect'), 300);
    }
  }, 5000);
  
  // Random emoji rain on landing page
  function createEmojiRain() {
    if (screens.landing && screens.landing.classList.contains('active')) {
      const emoji = gameData.floatingEmojis[Math.floor(Math.random() * gameData.floatingEmojis.length)];
      const rainDrop = document.createElement('div');
      rainDrop.textContent = emoji;
      rainDrop.style.cssText = `
        position: absolute;
        top: -50px;
        left: ${Math.random() * 100}%;
        font-size: 2rem;
        pointer-events: none;
        z-index: 6;
        animation: fall 4s linear forwards;
      `;
      
      // Add fall animation
      const style = document.createElement('style');
      style.textContent = `
        @keyframes fall {
          to {
            transform: translateY(100vh) rotate(360deg);
            opacity: 0;
          }
        }
      `;
      document.head.appendChild(style);
      
      screens.landing.appendChild(rainDrop);
      
      setTimeout(() => {
        if (rainDrop.parentNode) {
          rainDrop.parentNode.removeChild(rainDrop);
        }
      }, 4000);
    }
  }
  
  // Create emoji rain periodically
  setInterval(createEmojiRain, 3000 + Math.random() * 5000);
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  console.log('DOM Content Loaded - Brainrot Trials Starting...');
  init();
  setupButtonInteractions();
  initializeChaosEvents();
});

// Also initialize on window load as backup
window.addEventListener('load', () => {
  console.log('Window Loaded');
  if (!elements.themeToggle) {
    init();
    setupButtonInteractions();
    initializeChaosEvents();
  }
});

// Export for potential future use
window.BrainrotTrials = {
  gameState,
  gameData,
  showScreen,
  toggleTheme,
  resetGame,
  showDramaticMessage
};